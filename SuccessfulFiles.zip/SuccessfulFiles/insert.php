<?php
include("newconnection.php");
error_reporting(0);
?>


<html>
<head>
<style>

body
{
background:linear-gradient(pink,blue);
text-align:center;


}


</style>
</head>
<body>

<header  align="center" ><h2>Admission Form</h2></header>
    <form  actoin="" method="GET">
	Rollno<input type="text" name="rollno" value=""/><br><br>
	Name<input type="text" name="studentname" value=""/><br><br>
	class<input type="text" name="class" value=""/><br><br>
	<input type="submit" name="submit" value="submit"/>
	</form>
	
	
<?php
if($_GET['submit'])
{
  $rn=$_GET['rollno'];
  $sn=$_GET['studentname'];
  $cn=$_GET['class'];
  
  if($rn!="" && $sn!="" && $cn!="")
  {
	 $query = "INSERT INTO PERSON VALUES('$rn','$sn','$cn')";
     $data=mysqli_query($con,$query);

      if($data)
      {
	  echo "<font color='black' Bold>Data  Inserted successfully";
      } 
  }
   else
  {
	 echo "All Fields Are Required";
  }	 
 
}
//echo $rn;
//echo $sn;
//echo $cn;
?>	
</body>
</html>
