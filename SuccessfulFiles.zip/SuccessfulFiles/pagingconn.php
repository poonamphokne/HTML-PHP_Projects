<?php
$servername='localhost';
$username='root';
$password='';
$db='paging';

$con=mysqli_connect($servername,$username,$password,$db);

mysqli_select_db($con,$db);
if($con)
{
echo " ";
}else
{
die("Failed".mysqli_connect_error());
}




?>