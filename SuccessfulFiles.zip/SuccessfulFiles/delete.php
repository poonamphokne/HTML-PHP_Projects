<?php
include("newconnection.php");
$rollno=$_GET['rn'];
$query="DELETE FROM PERSON WHERE ROLLNO='$rollno'";
$data=mysqli_query($con,$query);

if($data)
{
	echo "<script>alert('Record Deleted')</script>";
	?>
	<META HTTP-EQUIV="Refresh" CONTENT="0; URL=http://localhost/successfulFiles/display.php">
	<?php
}
else
{
	echo "Not Deleted";
}

?>