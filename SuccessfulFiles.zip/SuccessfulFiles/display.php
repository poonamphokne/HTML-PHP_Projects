<style>
td
{
	padding:10px;
	
}
table
{
	border-colour:pink;
}
	
</style>

<?php
include("newconnection.php");
$query = "SELECT * FROM PERSON";
$data = mysqli_query($con,$query);
$total = Mysqli_num_rows($data);


if($total != 0)
{
	?>
	<br><br><br>
	<table align="center"  >
	<tr>
	    <th>Rollno</th>
		<th>Name</th>
		<th>Class</th>
		
		<th colspan="2">Operations</th>
	</tr>
	<?php
	while($result =mysqli_fetch_assoc($data))
	{
	echo "<tr>
	    <td>".$result['Rollno']."</td>
		<td>".$result['Name']."</td>
		<td>".$result['Class']."</td>
		
		<td><a href='update.php?rn=$result[Rollno]&sn=$result[Name]&cn=$result[Class]'>Edit</a></td>
		<td><a href='delete.php?rn=$result[Rollno] onclick='return checkdelete()'>Delete</a></td>
	     </tr>";
	}
	
}
else
{
echo "No Records";
}

?>
</table>

<script>
function checkdelete()
{
	confirm('Are You Sure You Want To Delete Record??');
}

</script>
