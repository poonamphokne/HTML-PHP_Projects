<html>
<head>
<title> paging in php</title>
</head>
<body>
<?php
error_reporting(0);
include("pagingconn.php");

//dividing pages
$page=$_GET['page'];
if($page=="" || $page=="1")
{
	$page1=0;
}
else
{
	$page1=($page*5)-5;
}
//display paging table
$query = "SELECT * FROM PAGING LIMIT $page1,5";
$data = mysqli_query($con,$query);



while($result =mysqli_fetch_assoc($data))
{
	echo $result['id']." ".$result['name'];
	echo "<br>";
	
}
//count no of pages
$query1 = "SELECT * FROM PAGING";
$data1 = mysqli_query($con,$query1);
$total = Mysqli_num_rows($data1);
$a=$total/5;
$a=ceil($a);
echo"<br>";echo"<br>";
    for($b=1;$b<=$a;$b++)
	{
	?><a href="paging.php?page=<?php echo $b; ?>" style="text-decoration:none"> <?php echo $b." "; ?></a><?php 
	
	}
	



?>
</body>
</html>