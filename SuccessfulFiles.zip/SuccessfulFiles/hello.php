<?php
include("newconnection.php");
$query = "INSERT INTO PERSON VALUES('2','sudhir','MBA')";
$data=mysqli_query($con,$query);

if($data)
{
	echo "Data  Inserted successfully";
}


?>