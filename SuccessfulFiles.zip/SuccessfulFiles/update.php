<?php
include("newconnection.php");
error_reporting(0);
 $_GET['rn'];
 $_GET['sn'];
 $_GET['cn'];
?>


<html>
<head>
<style>

body
{
background:linear-gradient(pink,blue);
text-align:center;


}


</style>
</head>
<body>

<header  align="center" ><h2>Admission Form</h2></header>
    <form  actoin="" method="GET">
	Rollno<input type="text" name="rollno" value="<?php echo $_GET['rn'];?>"/><br><br>
	Name<input type="text" name="studentname" value="<?php echo $_GET['sn'];?>"/><br><br>
	class<input type="text" name="class" value="<?php echo $_GET['cn'];?>"/><br><br>
	<input type="submit" name="submit" value="submit"/>
	</form>
	
	
<?php
if($_GET['submit'])
{
	$rollno=$_GET['rollno'];
	$name=$_GET['studentname'];
	$class=$_GET['class'];
	
   $query="UPDATE PERSON SET NAME='$name' ,CLASS='$class' WHERE ROLLNO='$rollno'";
   $data = mysqli_query($con,$query);
   
   if($data)
   {
	   echo "<font color='green'>Record updated sucessfully.<a href='display.php'>Check updated List here</a>";
   }
   else
   {
	   echo "<font color='red'>Record  Not updated.<a href='display.php'>Check updated List here</a>";
   }
}
else
{
 echo "<font color='blue'>Click on submit button to save the changes";
}
//echo $rn;
//echo $sn;
//echo $cn;
?>	
</body>
</html>
